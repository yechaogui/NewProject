# Weather
用C#编写的天气预报小工具
## 功能
#### 1、查询中国省份、城市及地区三级的天气预报；
#### 2、显示1-7天一周的天气预报及未来8-15天的天气预报；
#### 3、能定制地区的天气预报。
## 界面
![image](https://github.com/cnxy/Weather/blob/master/Weather/pic.png)
