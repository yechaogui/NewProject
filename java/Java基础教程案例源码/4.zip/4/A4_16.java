import java.util.Scanner;
public class A4_16 {
	public static void main(String[] args){
		System.out.println("������һ������");
		Scanner in=new Scanner(System.in);
		int number=in.nextInt();
		for(int i=0,j=number;i<=j;i++,j--){
			System.out.println(i+"+"+j+"="+(i+j));
		}
	} 
}
