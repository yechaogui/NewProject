import java.util.Scanner;
public class A4_17{
	public static void main(String[] args){
		Scanner in=new Scanner(System.in);
		for(;;){
			System.out.println("������");
			String flag=in.next();
			if(flag.equals("yes")){
				System.out.println("���������");
			}else{
				break;
			}
		}
	}
}