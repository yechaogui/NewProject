public class A4_2{
	public static void main(String[] args){
		
	}
}