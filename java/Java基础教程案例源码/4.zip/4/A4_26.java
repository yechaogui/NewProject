import java.util.Scanner;
public class A4_26{
	public static void main(String[] args){
		Scanner in=new Scanner(System.in);
		System.out.println("��������ݣ�");
		int year=in.nextInt();
		System.out.println("�������·ݣ�");
		int month=in.nextInt();
		int sum=0;
		for(int i=1900;i<year;i++){
			if(i%4==0&&i%100!=0||i%400==0){
				sum+=366;
			}else{
				sum+=365;
			}
		}
		for(int i=1;i<month;i++){
			if(i==2){
				if(year%4==0&&year%100!=0||year%400==0){
					sum+=29;
				}else{
					sum+=28;
				}
			}else{
				if(i==4||i==6||i==9||i==11){
					sum+=30;
				}else{
					sum+=31;
				}
			}
		}
		sum+=1;
		int wekday=sum%7;
		System.out.println("��\tһ\t��\t��\t��\t��\t��");
		for(int i=1;i<=wekday;i++){
			System.out.print("\t");
		}
		for(int i=1;i<=30;i++){
			if(sum%7==6){
				System.out.print(i+"\n");
			}else{
				System.out.print(i+"\t");
			}
			sum++;
		}
	}
}
