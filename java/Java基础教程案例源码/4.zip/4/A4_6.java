public class A4_6{
	public static void main(String[] args){
		int year=2006;
		int i=80000;
		while(i<200000){
			i=i+(i/100*25);
			year++;
		}
		System.out.println(year+"�꽫�ﵽ20����");
	}
}