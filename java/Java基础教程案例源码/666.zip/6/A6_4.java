public class A6_4{
	public static void main(String[] args){
		Person MyPerson=new Person();
		MyPerson.name="С���ŵ�";
		System.out.println(MyPerson.name);
		MyPerson.eat();
	}
}