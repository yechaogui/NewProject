public class A6_6{
	public static void main(String[] args){
		Person per=new Person();
		int age=per.getAge(18);
		System.out.println(age);
	}
}