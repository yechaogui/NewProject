public class A6_7{
	public static void main(String[] args){
		Test MyTest=new Test();
		System.out.println(MyTest.name);
	}
}