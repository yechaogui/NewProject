public class Test{
	String name;
}